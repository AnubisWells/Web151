package com.example.wellsa3715.m6ti_2_wells;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class GeoQuiz extends AppCompatActivity {

    private Button mTrueButton;
    private Button mFalseButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_geo_quiz);

        mTrueButton = findViewById(R.id.button_true);
        mTrueButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast.makeText(GeoQuiz.this,
                        //R.strings.correct_toast,
                        "Correct",
                        Toast.LENGTH_SHORT).show();
            }
        });
        mFalseButton = findViewById(R.id.button_false);
        mFalseButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast.makeText(GeoQuiz.this,
                        //R.strings.incorrect_toast,
                        "Incorrect",
                        Toast.LENGTH_SHORT).show();

            }
        });

    }
}
